// Adapted from https://github.com/RaddyTheBrand/Nodejs-User-Management-Express-EJS-MongoDB



require('dotenv').config(); // Load environment variables from a .env file


// Import necessary libraries and modules
const express = require('express');
const expressLayout = require('express-ejs-layouts');
const methodOverride = require('method-override');
const flash = require('connect-flash');
const session = require('express-session');
const connectDB = require('./server/config/database');



// Create the Express application with the designated port
const app = express();
const port = 5000 || process.env.PORT; 


// Connect to the MongoDB database
connectDB();




// Configure middleware for request and response processing
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded form data
app.use(express.json()); // Parse JSON data
app.use(methodOverride('_method')); // Enable HTTP method overrides for forms




// Serve static files from the 'public' directory
app.use(express.static('public'));


// Configure Express session for storing user data
app.use(
    session({
      secret: 'secret',
      resave: false,
      saveUninitialized: true,
      cookie: {
        maxAge: 1000 * 60 * 60 * 24 * 7, // 1 week
      }
    })
  );

  
// Enable Flash Messages
app.use(flash({ sessionKeyName: 'flashMessage' }));





// Configure the template engine (EJS) and layout
app.use(expressLayout);
app.set('layout', './layouts/main');
app.set('view engine', 'ejs');




// Define and use the routes for handling application logic
app.use('/', require('./server/routes/event')); // Use the CRUD event-related routes




// Handle 404 errors by rendering a '404' view
app.get('*', (req, res) => {
    res.status(404).render('404');
});



// Start the server and listen for incoming requests on the specified port
app.listen(port, () => {
    console.log(`App listening on port ${port}`);
});