// Import necessary modules
const Event = require('../models/Mevent');
const mongoose = require("mongoose");

// Disable strict query mode for mongoose
mongoose.set('strictQuery', false);

// Routes Handlers


// Signup Page
exports.signupPage = async (req, res) => {
    const locals = {
        title: 'Sign Up',
        description: 'Create your Stacherian account to get started.',
    };

    res.render('signup', locals);
};






// Homepage
exports.homepage = async (req, res) => {
    try {
        const messages = await req.flash('info');
        const locals = {
            title: 'Stacherian Event Management',
            description: 'Stacherian',
            messages: messages,
        };

        // Pagination settings
        let perPage = 10;
        let page = req.query.page || 1;

        // Fetch and aggregate events with sorting, pagination, and counting
        const events = await Event.aggregate([{ $sort: { createdAt: -1 } }])
            .skip(perPage * page - perPage)
            .limit(perPage)
            .exec();

        const count = await Event.countDocuments();

        res.render('index', {
            locals,
            events,
            current: page,
            pages: Math.ceil(count / perPage),
            messages
        });
    } catch (error) {
        console.log(error);
    }
};

// New Event Form
exports.eventForm = async (req, res) => {
    const locals = {
        title: 'Add an Event',
        description: 'Just add the event, we will take care of the rest',
    };

    res.render('event/create', locals);
};

// Create New Event
exports.createEvent = async (req, res) => {
    console.log(req.body);

    const newEvent = new Event(req.body);

    try {
        await Event.create(newEvent);
        req.flash('info', 'Succesfully added an event.');
        res.redirect('/');
    } catch (error) {
        console.error(error);
    }
};

// View Event Data
exports.view = async (req, res) => {
    try {
        const event = await Event.findOne({ _id: req.params.id });
        const locals = {
            title: "View Event Data",
            description: "This will enable registered alumni and Manager to view a specific event",
        };

        res.render('event/view', {
            locals,
            event
        });
    } catch (error) {
        console.error(error);
    }
};

// Update/Edit Event Data
exports.update = async (req, res) => {
    try {
        const event = await Event.findOne({ _id: req.params.id });
        const locals = {
            title: "Update Event Data",
            description: "Just add the event, we will take care of the rest",
        };

        res.render('event/update', {
            locals,
            event
        });
    } catch (error) {
        console.error(error);
    }
};

// Update/Edit Event Data - POST
exports.updatePost = async (req, res) => {
    try {
        await Event.findByIdAndUpdate(req.params.id, req.body);
        req.flash('info', `Event '${req.body.event_title}' has been updated.`);
        res.redirect('/');
        console.log('redirected');
    } catch (error) {
        console.error(error);
    }
};

// Delete/Remove Event Data
exports.deleteEvent = async (req, res) => {
    try {
        await Event.deleteOne({ _id: req.params.id });
        req.flash('info', ' Event has been deleted.');
        res.redirect('/');
    } catch (error) {
        console.error(error);
    }
};

// Search Event Data
exports.searchEvents = async (req, res) => {
    const query = req.query.query;
    const locals = {
        title: "Search Event Data ",
        description: "This will enable registered alumni and Manager to search for specific events",
    };

    try {
        let searchTerm = req.body.searchTerm;
        const searchNoSpecialChar = searchTerm.replace(/[^a-zA-Z0-9 ]/g, "");
        const events = await Event.find({
            $or: [
                { event_title: { $regex: new RegExp(searchNoSpecialChar, 'i') } },
                { event_category: { $regex: new RegExp(searchNoSpecialChar, 'i') } },
                { location: { $regex: new RegExp(searchNoSpecialChar, 'i') } },
                { description: { $regex: new RegExp(searchNoSpecialChar, 'i') } },
            ]
        });

        res.render("search", {
            events,
            locals,
            searchTerm,
        });
    } catch (error) {
        console.error(error);
    }
};

// My Events Page
exports.myevents = async (req, res) => {
    try {
        const messages = await req.flash('info');
        const locals = {
            title: 'Stacherian',
            description: 'Stacherian Event Management',
            messages: messages,
        };

        // Pagination settings
        let perPage = 10;
        let page = req.query.page || 1;

        // Fetch and aggregate events with sorting, pagination, and counting
        const events = await Event.aggregate([{ $sort: { createdAt: -1 } }])
            .skip(perPage * page - perPage)
            .limit(perPage)
            .exec();

        const count = await Event.countDocuments();

        res.render('event/my-events', {
            locals,
            events,
            current: page,
            pages: Math.ceil(count / perPage),
            messages
        });
    } catch (error) {
        console.log(error);
    }
};
