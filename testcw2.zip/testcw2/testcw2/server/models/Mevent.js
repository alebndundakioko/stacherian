//Adapted from https://github.com/RaddyTheBrand/Nodejs-User-Management-Express-EJS-MongoDB 

// Import Mongoose
const mongoose = require('mongoose');


// Schema Definiton for the Event model
const Schema = mongoose.Schema;
const EventSchema = Schema({
    event_title: { 
        type: String, 
        required: true 
    },

    event_category: {
        type: String,
        required: true,
    },

    date: {
        type: Date,
        required: true,
    },

    location: { 
        type: String, 
        required: true 
    },

    start_time: {
        type: Date,
        required: true,
    },

    end_time: {
        type: Date,
        required: true,
    },


    description: { 
        type: String, 
        required: true 
    },

    image: { 
        type: String,  // Store the image file path
        required: false 
    },

    createdAt: { 
        type: Date, 
        default: Date.now()
    },

    updatedAt: { 
        type: Date, 
        default: Date.now()
   
    }


})




module.exports = mongoose.model('Event', EventSchema);