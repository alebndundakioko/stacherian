// Import the mongoose library for MongoDB to connect with a database
const mongoose = require('mongoose');

// Disable strict query mode for mongoose
mongoose.set('strictQuery', false);

// Asynchronous function to connect to the MongoDB database
const establishDatabaseConnection = async () => {
  try {
    // Connect to the MongoDB database using the provided URI
    const connection = await mongoose.connect(process.env.MONGODB_URI);

    // If the connection is successful, log a message in the terminal
    console.log(`MongoDB Database Connected: ${connection.connection.host}`);
  } catch (error) {
    // If an error occurs during the connection attempt, log the error for debugging
    console.error(error);
  }
};

// Export the function to establish the database connection
module.exports = establishDatabaseConnection;
