//Adapted from https://github.com/RaddyTheBrand/Nodejs-User-Management-Express-EJS-MongoDB 


const express = require('express');
const router = express.Router();
const eventController = require('../controllers/eventController');


/**
 *   Event Routes 
*/


// Define routes and their corresponding controller functions
router.get('/', eventController.homepage);
router.get('/create', eventController.eventForm);
router.post('/create', eventController.createEvent);
router.get('/view/:id', eventController.view);

router.get('/update/:id', eventController.update);
router.put('/update/:id', eventController.updatePost);
router.delete('/update/:id', eventController.deleteEvent);

router.post('/search', eventController.searchEvents);

router.get('/my-events', eventController.myevents);


module.exports = router;